import secrets
print(secrets.token_hex(16))  # Generates a 32-character hex key
